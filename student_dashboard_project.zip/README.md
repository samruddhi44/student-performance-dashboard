# 🎓 Student Performance Dashboard (Python + Pandas + Matplotlib)

This is a simple Python project that analyzes student performance data from a CSV file. It calculates total marks, average, grades, and generates charts.

## 🔧 Features
- Read student marks from CSV
- Calculate:
  - Total & Average Marks
  - Grade (A, B, C, D)
  - Pass or Fail
  - Identify Topper
- Generate:
  - Bar chart of subject-wise marks
  - Pie chart of Pass vs Fail status

## 📁 Files
- `students.csv` – contains sample student data
- `student_dashboard.py` – main Python code
- `README.md` – this file

## 📊 Sample Data (`students.csv`)
```csv
Name,Maths,Science,English
Samruddhi,78,82,90
Rahul,56,60,52
Priya,92,88,95
Karan,33,40,35
Sneha,85,89,87
```

## 📦 Libraries Used
- `pandas`
- `matplotlib`

## ✅ How to Run
```bash
pip install pandas matplotlib
python student_dashboard.py
```

## ✍️ Author
Samruddhi Narute